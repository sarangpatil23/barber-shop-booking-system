
# 💈 Barber Shop Service Booking Application

## ⚙️ How to Use

Follow the steps below to run and use the application:

### 1️⃣ Setup Database
- Create a MySQL database named:
  
  CREATE DATABASE barbershop;

- Import the SQL file (if provided).

---

### 2️⃣ Configure Database Connection
- Open `DBConnection.java`
- Update:
  - Database URL
  - Username
  - Password

Example:
jdbc:mysql://localhost:3306/barbershop

---

### 3️⃣ Run on Apache Tomcat
- Import project into Eclipse / STS
- Add Apache Tomcat Server
- Right click project → Run on Server

---

### 4️⃣ Access Application
Open browser:

http://localhost:8080/YourProjectName

---

## 🔑 Default Login Credentials

### Admin Login
- **Username:** admin  
- **Password:** 1234  

Use these credentials to log in as admin and manage services and bookings.

---

## 👨‍💻 Author
Sarang Patil
