<?php
// invoice.php
include 'connect.php';

if (!isset($_GET['appointment_id'])) {
    echo "No appointment selected.";
    exit;
}

$appointment_id = $_GET['appointment_id'];

// Fetch appointment details
$sql = "SELECT a.id, a.appointment_date, a.appointment_time, s.name AS service_name, s.price, u.name AS customer_name
        FROM appointments a
        JOIN services s ON a.service_id = s.id
        JOIN users u ON a.user_id = u.id
        WHERE a.id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $appointment_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Invalid appointment ID.";
    exit;
}

$row = $result->fetch_assoc();

?>

<!DOCTYPE html>
<html>
<head>
    <title>Appointment Invoice</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 50px;
        }

        .invoice-box {
            max-width: 600px;
            padding: 30px;
            border: 1px solid #eee;
            box-shadow: 0 0 10px #aaa;
        }

        h2 {
            text-align: center;
        }

        .details {
            margin-top: 20px;
        }

        .details table {
            width: 100%;
        }

        .details td {
            padding: 5px 0;
        }

        .footer {
            text-align: center;
            margin-top: 40px;
            font-size: 12px;
            color: gray;
        }
    </style>
</head>
<body>

<div class="invoice-box">
    <h2>Barbershop Appointment Invoice</h2>
    <div class="details">
        <table>
            <tr>
                <td><strong>Invoice ID:</strong></td>
                <td><?php echo $row['id']; ?></td>
            </tr>
            <tr>
                <td><strong>Customer:</strong></td>
                <td><?php echo htmlspecialchars($row['customer_name']); ?></td>
            </tr>
            <tr>
                <td><strong>Service:</strong></td>
                <td><?php echo htmlspecialchars($row['service_name']); ?></td>
            </tr>
            <tr>
                <td><strong>Date:</strong></td>
                <td><?php echo $row['appointment_date']; ?></td>
            </tr>
            <tr>
                <td><strong>Time:</strong></td>
                <td><?php echo $row['appointment_time']; ?></td>
            </tr>
            <tr>
                <td><strong>Price:</strong></td>
                <td>₹<?php echo number_format($row['price'], 2); ?></td>
            </tr>
        </table>
    </div>
    <div class="footer">
        Thank you for booking with us!
    </div>
</div>

</body>
</html>
