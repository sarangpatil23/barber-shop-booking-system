ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'includes/phpmailer/PHPMailer.php';
require 'includes/phpmailer/SMTP.php';
require 'includes/phpmailer/Exception.php';


use PHPMailer\PHPMailer\Exception as PHPMailerException;



function sendConfirmationEmail($toEmail, $toName, $subject, $body) {
    $mail = new PHPMailer(true);
	
    try {
		$mail->isSMTP();
		$mail->Host       = 'smtp.gmail.com';
		$mail->SMTPAuth   = true;
		$mail->Username   = 'sarangpatil348@gmail.com';       // your Gmail
		$mail->Password   = 'tueinnrfmwalmcqe';              // your Gmail app password
		$mail->SMTPSecure = 'tls';
		$mail->Port       = 587;
	
		// ✅ Skip SSL certificate verification (local dev only!)
		$mail->SMTPOptions = [
			'ssl' => [
				'verify_peer'       => false,
				'verify_peer_name'  => false,
				'allow_self_signed' => true,
			]
			];
	
		$mail->setFrom('sarangpatil348@gmail.com', 'Shree Men Salon');
        $mail->addAddress($toEmail, $toName);

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $body;

        $mail->send();
    } catch (PHPMailerException $e) {
        error_log("Email sending failed: {$mail->ErrorInfo}");
    }
}

include "connect.php";
include "Includes/functions/functions.php";
include "Includes/templates/header.php";
include "Includes/templates/navbar.php";
?>
<!-- Appointment Page Stylesheet -->
<link rel="stylesheet" href="Design/css/appointment-page-style.css">

<!-- BOOKING APPOINTMENT SECTION -->

<section class="booking_section">
	<div class="container">

		<?php

            if(isset($_POST['submit_book_appointment_form']) && $_SERVER['REQUEST_METHOD'] === 'POST')
            {
            	$selected_services = $_POST['selected_services'];
                $selected_employee = $_POST['selected_employee'];
                $selected_date_time = explode(' ', $_POST['desired_date_time']);
if (count($selected_date_time) < 3) {
    echo "<div class='alert alert-danger'>Invalid date/time format. Please select again.</div>";
} else {
    $date_selected = $selected_date_time[0];
    $start_time = $date_selected." ".$selected_date_time[1];
    $end_time = $date_selected." ".$selected_date_time[2];

                $client_first_name = test_input($_POST['client_first_name']);
                $client_last_name = test_input($_POST['client_last_name']);
                $client_phone_number = test_input($_POST['client_phone_number']);
                $client_email = test_input($_POST['client_email']);
				$emp_selected =test_input($_POST['selected_employee']);

                $con->beginTransaction();

					try {
						$stmtCheckClient = $con->prepare("SELECT * FROM clients WHERE client_email = ?");
						$stmtCheckClient->execute([$client_email]);

						$client_count = $stmtCheckClient->rowCount();

						if ($client_count > 0) {
							$client_data = $stmtCheckClient->fetch(PDO::FETCH_ASSOC);
							$client_id = $client_data['client_id'];
						} else {
							$stmtClient = $con->prepare("INSERT INTO clients (first_name, last_name, phone_number, client_email) VALUES (?, ?, ?, ?)");
							$stmtClient->execute([$client_first_name, $client_last_name, $client_phone_number, $client_email]);
							$client_id = $con->lastInsertId();
						}

						$stmt_appointment = $con->prepare("INSERT INTO appointments (date_created, client_id, employee_id, start_time, end_time_expected) VALUES (?, ?, ?, ?, ?)");
						$stmt_appointment->execute([date("Y-m-d H:i"), $client_id, $selected_employee, $start_time, $end_time]);
						$appointment_id = $con->lastInsertId();

						foreach ($selected_services as $service) {
							$stmt = $con->prepare("INSERT INTO services_booked (appointment_id, service_id) VALUES (?, ?)");
							$stmt->execute([$appointment_id, $service]);
						}

						echo "<div class='alert alert-success'>Great! Your appointment has been created successfully.</div>";
						$con->commit();

                        $toEmail = $client_email;
                        $toName = $client_first_name . ' ' . $client_last_name;
						

                        $subject = "Appointment Confirmation - Barbershop";
                        $body = "<p>Dear $toName,</p>
						<p>Congratulation ! Your Slot booking with us confirmed and your barber's ID is $emp_selected.</p>
						<p><strong>Date:</strong> $date_selected<br>
						<strong>Time:</strong> " . date('h:i A', strtotime($start_time)) . " - " . date('h:i A', strtotime($end_time)) . "</p>
						<p>We look forward to seeing you!</p>
						<p><em>Barbershop Team</em></p>";
     sendConfirmationEmail($toEmail, $toName, $subject, $body);
					} catch (Exception $e) {
						$con->rollBack();
						echo "<div class='alert alert-danger'>" . $e->getMessage() . "</div>";
					}
            }
		}
        ?>


		<!-- RESERVATION FORM -->

		<form method="post" id="appointment_form" action="appointment.php">
		
			<!-- SELECT SERVICE -->

			<div class="select_services_div tab_reservation" id="services_tab">

				<!-- ALERT MESSAGE -->

				<div class="alert alert-danger" role="alert" style="display: none">
					Please, select at least one service!
				</div>

				<div class="text_header">
					<span>
						1. Choice of services
					</span>
				</div>

				<!-- SERVICES TAB -->
				
				<div class="items_tab">
        			<?php
        				$stmt = $con->prepare("Select * from services");
                    	$stmt->execute();
                    	$rows = $stmt->fetchAll();

                    	foreach($rows as $row)
                    	{
                        	echo "<div class='itemListElement'>";
                            	echo "<div class = 'item_details'>";
                                	echo "<div>";
                                    	echo $row['service_name'];
                                	echo "</div>";
                                	echo "<div class = 'item_select_part'>";
                                		echo "<span class = 'service_duration_field'>";
                                    		echo $row['service_duration']." min";
                                    	echo "</span>";
                                    	echo "<div class = 'service_price_field'>";
    										echo "<span style = 'font-weight: bold;'>";
                                    			echo $row['service_price']."₹";
                                    		echo "</span>";
                                    	echo "</div>";
                                    ?>
                                    	<div class="select_item_bttn">
                                    		<div class="btn-group-toggle" data-toggle="buttons">
												<label class="service_label item_label btn btn-secondary">
													<input type="checkbox"  name="selected_services[]" value="<?php echo $row['service_id'] ?>" autocomplete="off">Select
												</label>
											</div>
                                    	</div>
                                    <?php
                                	echo "</div>";
                            	echo "</div>";
                        	echo "</div>";
                    	}
            		?>
    			</div>
			</div>

			<!-- SELECT EMPLOYEE -->

			<div class="select_employee_div tab_reservation" id="employees_tab">

				<!-- ALERT MESSAGE -->

				<div class="alert alert-danger" role="alert" style="display: none">
					Please, select your employee!
				</div>

				<div class="text_header">
					<span>
						2. Choice of employee
					</span>
				</div>

				<!-- EMPLOYEES TAB -->
				
				<div class="btn-group-toggle" data-toggle="buttons">
					<div class="items_tab">
        				<?php
        					$stmt = $con->prepare("Select * from employees");
                    		$stmt->execute();
                    		$rows = $stmt->fetchAll();

                    		foreach($rows as $row)
                    		{
                        		echo "<div class='itemListElement'>";
                            		echo "<div class = 'item_details'>";
                                		echo "<div>";
                                    		echo $row['first_name']." ".$row['last_name'];
                                		echo "</div>";
                                		echo "<div class = 'item_select_part'>";
                                    ?>
                                    		<div class="select_item_bttn">
                                    			<label class="item_label btn btn-secondary active">
													<input type="radio" class="radio_employee_select" name="selected_employee" value="<?php echo $row['employee_id'] ?>">Select
												</label>	
                                    		</div>
                                    <?php
                                		echo "</div>";
                            		echo "</div>";
                        		echo "</div>";
                    		}
            			?>
    				</div>
    			</div>
			</div>


			<!-- SELECT DATE TIME -->

			<div class="select_date_time_div tab_reservation" id="calendar_tab">

				<!-- ALERT MESSAGE -->
				
		        <div class="alert alert-danger" role="alert" style="display: none">
		          Please, select time!
		        </div>

				<div class="text_header">
					<span>
						3. Choice of Date and Time
					</span>
				</div>
				
				<div class="calendar_tab" style="overflow-x: auto;overflow-y: visible;" id="calendar_tab_in">
					<div id="calendar_loading">
						<img src="Design/images/ajax_loader_gif.gif" style="display: block;margin-left: auto;margin-right: auto;">
					</div>
				</div>

			</div>


			<!-- CLIENT DETAILS -->

			<div class="client_details_div tab_reservation" id="client_tab">

                <div class="text_header">
                    <span>
                        4. Client Details
                    </span>
                </div>

                <div>
                    <div class="form-group colum-row row">
                        <div class="col-sm-6">
                            <input type="text" name="client_first_name" id="client_first_name" class="form-control" placeholder="First Name">
							<span class = "invalid-feedback">This field is required</span>
                        </div>
                        <div class="col-sm-6">
                            <input type="text" name="client_last_name" id="client_last_name" class="form-control" placeholder="Last Name">
							<span class = "invalid-feedback">This field is required</span>
                        </div>
                        <div class="col-sm-6">
                            <input type="email" name="client_email" id="client_email" class="form-control" placeholder="E-mail">
							<span class = "invalid-feedback">Invalid E-mail</span>
                        </div>
                        <div class="col-sm-6">
                            <input type="text"  name="client_phone_number" id="client_phone_number" class="form-control" placeholder="Phone number">
							<span class = "invalid-feedback">Invalid phone number</span>
						</div>
                    </div>
        
                </div>
            </div>


			

			<!-- NEXT AND PREVIOUS BUTTONS -->

			<div style="overflow:auto;padding: 30px 0px;">
    			<div style="float:right;">
    				<input type="hidden" name="submit_book_appointment_form">
      				<button type="button" id="prevBtn"  class="next_prev_buttons" style="background-color: #bbbbbb;"  onclick="nextPrev(-1)">Previous</button>
      				<button type="button" id="nextBtn" class="next_prev_buttons" onclick="nextPrev(1)">Next </button>
    			</div>
  			</div>

  			<!-- Circles which indicates the steps of the form: -->

  			<div style="text-align:center;margin-top:40px;">
    			<span class="step"></span>
    			<span class="step"></span>
    			<span class="step"></span>
    			<span class="step"></span>
  			</div>

		</form>
	</div>
</section>



<!-- FOOTER BOTTOM -->

<?php include "Includes/templates/footer.php"; ?>
