<<?php
    $host = 'localhost'; // Use IP instead of 'localhost' to avoid socket issues
    $db   = 'barbershop';
    $user = 'root';
    $pass = '';
    $charset = 'utf8';

    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES $charset"
    ];

    try {
        $con = new PDO($dsn, $user, $pass, $options);
        // echo "Database connection successful!";
    } catch (PDOException $ex) {
        echo "Failed to connect with database! " . $ex->getMessage();
        die();
    }
?>
