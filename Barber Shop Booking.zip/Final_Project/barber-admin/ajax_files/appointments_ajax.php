<?php 

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../includes/phpmailer/PHPMailer.php';
require '../includes/phpmailer/SMTP.php';
require '../includes/phpmailer/Exception.php';
include '../connect.php';
include '../Includes/functions/functions.php';

if (isset($_POST['do']) && $_POST['do'] == "Cancel Appointment") {
   
    $appointment_id = $_POST['appointment_id'];
    $reason = $_POST['cancellation reason'];

    // Get client email and name using JOIN
    $stmt = $con->prepare("SELECT clients.client_email, clients.first_name, clients.last_name
                           FROM appointments
                           JOIN clients ON appointments.client_id = clients.client_id
                           WHERE appointments.appointment_id = ?");
    $stmt->execute([$appointment_id]);
    $client = $stmt->fetch();

    if ($client) {
        // Delete the appointment
        $deleteStmt = $con->prepare("DELETE FROM appointments WHERE appointment_id = ?");
        $deleteStmt->execute([$appointment_id]);

        if ($deleteStmt->rowCount() > 0) {
            // Send cancellation email
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'sarangpatil348@gmail.com';
                $mail->Password = 'tueinnrfmwalmcqe';
                $mail->SMTPSecure = 'tls';
                $mail->Port = 587;

                $mail->SMTPOptions = [
                    'ssl' => [
                        'verify_peer' => false,
                        'verify_peer_name' => false,
                        'allow_self_signed' => true,
                    ]
                ];

                $mail->setFrom('sarangpatil348@gmail.com', 'Shree Men Salon');
                $mail->addAddress($client['client_email'], $client['first_name'] . ' ' . $client['last_name']);

                $mail->isHTML(true);
                $mail->Subject = 'Appointment Cancelled';
                $mail->Body = "
                     <h2>Dear {$client['first_name']},</h2>
                    <p>Sorry! Your appointment (ID: $appointment_id) has been cancelled. Please Call 8856018054 for cancellation details or ask any problem here. </p>
                    
                    <br><p>Thank you,<br>Shree Men Salon</p>
                ";

                $mail->send();
                echo "Appointment cancelled and email sent successfully.";
            } catch (Exception $e) {
                echo "Appointment cancelled, but email failed: " . $mail->ErrorInfo;
            }
        } else {
            echo "Failed to cancel appointment.";
        }
    } else {
        echo "Client not found.";
    }
}

elseif (isset($_POST['do']) && $_POST['do'] == "Delete Appointment") {
    $client_id = $_POST['client_id'];
    $start_time = $_POST['start_time'];

    if (is_numeric($client_id) && !empty($start_time)) {
        $stmt = $con->prepare("DELETE FROM appointments WHERE client_id = ? AND start_time = ?");
        $stmt->execute([$client_id, $start_time]);

        if ($stmt->rowCount() > 0) {
            echo "Appointment deleted successfully.";
        } else {
            echo "No matching appointment found.";
        }
    } else {
        echo "Invalid input.";
    }
}
?>
